﻿*** Hướng dẫn ***

1/ Đăng ký:
Chạy file register.bat
Nếu có thông báo hỏi... thì lựa chọn Yes.

2/ Hủy đăng ký:
Chạy file unregister.bat
Nếu có thông báo hỏi... thì lựa chọn Yes.

3/ Lưu ý:
+ Không chạy trực tiếp file VBALib.exe
+ Các files [ register.bat, unregister.bat, VBALib.exe ] đặt vào chung một folder.

4/ Nếu không thực hiện đăng ký / hủy đăng ký bằng cách chạy file register.bat, unregister.bat thì có thể dùng CMD Dos hoặc PowerShell:
PyLibImportDBF.exe --register
PyLibImportDBF.exe --unregister